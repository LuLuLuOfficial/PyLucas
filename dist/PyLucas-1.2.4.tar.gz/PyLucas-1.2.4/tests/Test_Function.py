from src.Function.Function import Author_Lucas, GetTimeStamp

if __name__ == '__main__':
    print(Author_Lucas())
    print(GetTimeStamp())