ReadMe
Its a Python Func Lib from Nuhil Lucas.

Build
Command:
Pack Up:
python setup.py sdist
Pip Install:
pip install E:\Warehouse\Project\Program_LucasLib\PyLucas\dist\PyLucas-X.X.X.tar.gz
