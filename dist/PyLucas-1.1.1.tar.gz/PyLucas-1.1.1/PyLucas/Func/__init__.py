__all__ = ['Author_Lucas', 'GetTimeStamp']

from PyLucas.Func.Function import Author_Lucas, GetTimeStamp