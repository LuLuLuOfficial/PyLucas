__all__ = ["__version__"]

__version__ = version = '1.2.1'
# __description__ = "Personal utility library for Nuhil Lucas."
