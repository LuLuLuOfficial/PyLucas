# Welcome To PyLucas

Its a Python Func Lib from Nuhil Lucas.

#### Command:

###### Pack Up:

- python setup.py sdist

###### Pip Install:

- pip install ...\PyLucas-X.X.X.tar.gz
